import { Component, OnInit, inject, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

import { TranslatePipe, TranslateService } from '@ngx-translate/core';

import { LANGUAGES } from 'app/config';
import { Account, AccountService } from 'app/core/auth';
import { AlertError } from 'app/shared/alert';
import { FindLanguageFromKeyPipe, TranslateDirective } from 'app/shared/language';

const initialAccount: Account = {} as Account;

@Component({
  selector: 'jhi-settings',
  imports: [TranslateDirective, TranslatePipe, FindLanguageFromKeyPipe, AlertError, ReactiveFormsModule],
  templateUrl: './settings.html',
})
export default class Settings implements OnInit {
  readonly success = signal(false);
  languages = LANGUAGES;

  settingsForm = new FormGroup({
    firstName: new FormControl(initialAccount.firstName, {
      nonNullable: true,
      validators: [Validators.required, Validators.minLength(1), Validators.maxLength(50)],
    }),
    lastName: new FormControl(initialAccount.lastName, {
      nonNullable: true,
      validators: [Validators.required, Validators.minLength(1), Validators.maxLength(50)],
    }),
    email: new FormControl(initialAccount.email, {
      nonNullable: true,
      validators: [Validators.required, Validators.minLength(5), Validators.maxLength(254), Validators.email],
    }),
    langKey: new FormControl(initialAccount.langKey, { nonNullable: true }),
    activated: new FormControl(initialAccount.activated, { nonNullable: true }),
    authorities: new FormControl(initialAccount.authorities, { nonNullable: true }),
    imageUrl: new FormControl(initialAccount.imageUrl, { nonNullable: true }),
    login: new FormControl(initialAccount.login, { nonNullable: true }),
  });

  private readonly accountService = inject(AccountService);
  private readonly translateService = inject(TranslateService);

  ngOnInit(): void {
    this.accountService.identity().subscribe(account => {
      if (account) {
        this.settingsForm.patchValue(account);
      }
    });
  }

  save(): void {
    this.success.set(false);

    const account = this.settingsForm.getRawValue();
    this.accountService.save(account).subscribe({
      next: () => {
        this.success.set(true);

        this.accountService.authenticate(account);

        if (account.langKey !== this.translateService.getCurrentLang()) {
          this.translateService.use(account.langKey);
        }
      },
      error() {
        // Handled by interceptor.
      },
    });
  }
}
