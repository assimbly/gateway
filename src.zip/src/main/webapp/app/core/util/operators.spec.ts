import { describe, expect, it } from 'vitest';

import { filterNaN } from './operators';

describe('Operators Test', () => {
  describe('filterNaN', () => {
    it('should return 0 for NaN', () => {
      expect(filterNaN(Number.NaN)).toBe(0);
    });
    it('should return number for a number', () => {
      expect(filterNaN(12345)).toBe(12345);
    });
  });
});
